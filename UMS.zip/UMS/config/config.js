const sessionSecret = "mysitesessionsecret";

const emailUser = "tayyabmuneeb27@gmail.com";
const emailPassword = "eespjjpqqffxxhfx";

module.exports ={
   sessionSecret,
   emailUser,
   emailPassword
}